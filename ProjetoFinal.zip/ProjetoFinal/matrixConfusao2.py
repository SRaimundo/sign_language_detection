#MATRIZ DE CONFUSAO DA INF692NET
import torch
from torchvision import datasets
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

device = "cuda" if torch.cuda.is_available() else "cpu"
print(device)

data_transform = transforms.Compose([
	transforms.Resize((128, 128)),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

train_dir = 'ASL_Alphabet_Dataset/train'
test_dir = 'ASL_Alphabet_Dataset/test'

train_data = datasets.ImageFolder(root = train_dir, transform = data_transform, target_transform = None)    

test_data = datasets.ImageFolder(root = test_dir, transform = data_transform, target_transform = None)    

batch_size = 32
train_dataloader = DataLoader(dataset = train_data, batch_size = batch_size, num_workers = 1, shuffle = True)

test_dataloader = DataLoader(dataset = test_data, batch_size = batch_size, num_workers = 1,shuffle = False)

class INF692Net(torch.nn.Module):
    def __init__(self):
        super(INF692Net, self).__init__()

        self.layer1 = torch.nn.Sequential(
            torch.nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1),
            torch.nn.BatchNorm2d(32),
            torch.nn.ReLU(),
            torch.nn.MaxPool2d(kernel_size = 2, stride = 2)) # 64x64
        self.layer2 = torch.nn.Sequential(
            torch.nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            torch.nn.BatchNorm2d(64),
            torch.nn.ReLU(), 
            torch.nn.MaxPool2d(kernel_size = 2, stride = 2)) # 32x32
        self.layer3 = torch.nn.Sequential(
            torch.nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            torch.nn.BatchNorm2d(128),
            torch.nn.ReLU(),
            torch.nn.MaxPool2d(kernel_size = 2, stride = 2)) # 16x16
        self.fc = torch.nn.Sequential(
            torch.nn.Linear(16*16*128, 64),
            torch.nn.ReLU())
        self.fc1 = torch.nn.Sequential(
            torch.nn.Linear(64, 128),
            torch.nn.ReLU())
        self.fc2 = torch.nn.Sequential(
            torch.nn.Dropout(0.25),
            torch.nn.Linear(128, 128),
            torch.nn.ReLU())
        self.fc3= torch.nn.Sequential(
            torch.nn.Dropout(0.25),
            torch.nn.Linear(128, 21))

    def forward(self, x):
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = out.reshape(out.size(0), -1)
        out = self.fc(out)
        out = self.fc1(out)
        out = self.fc2(out)
        out = self.fc3(out)
        return out


model = INF692Net().to('cpu')

model.load_state_dict(torch.load('models/INF692NetHenriqueI10.pth', map_location=torch.device(device)))
model.eval()


y_true, y_pred = [], []

for images, labels in test_dataloader:

    outputs = model(images)

    predicted = outputs.data.argmax(dim=1)
    y_true.extend(labels)
    y_pred.extend(predicted)


labels = train_data.classes  

confusion_mtx = confusion_matrix(y_true, y_pred)

disp = ConfusionMatrixDisplay(confusion_matrix=confusion_mtx, display_labels=labels)

f, ax = plt.subplots(figsize=(20, 20))
disp.plot(ax=ax, cmap="Greens")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix")
plt.show()
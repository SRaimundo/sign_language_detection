#MATRIZ DE CONFUSAO DA RESNET18

import torch
import torchvision
from torchvision import datasets
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

device = "cuda" if torch.cuda.is_available() else "cpu"
print(device)

data_transform = torchvision.models.ResNet18_Weights.IMAGENET1K_V1.transforms()

train_dir = 'ASL_Alphabet_Dataset/train'
test_dir = 'ASL_Alphabet_Dataset/test'

train_data = datasets.ImageFolder(root = train_dir, transform = data_transform, target_transform = None)    

test_data = datasets.ImageFolder(root = test_dir, transform = data_transform, target_transform = None)    

batch_size = 32
train_dataloader = DataLoader(dataset = train_data, batch_size = batch_size, num_workers = 1, shuffle = True)

test_dataloader = DataLoader(dataset = test_data, batch_size = batch_size, num_workers = 1,shuffle = False)

class INF692Net(torch.nn.Module):
    def __init__(self):
        super(INF692Net, self).__init__()
        self.resnet = torchvision.models.resnet18(weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)
        num_features = self.resnet.fc.in_features
        self.resnet.fc = torch.nn.Linear(num_features, 21)
        

    def forward(self, x):
        out = self.resnet(x)
        return out


model = INF692Net().to('cpu')

model.load_state_dict(torch.load('models/INF692NetResNET18.pth', map_location=torch.device(device)))
model.eval()


y_true, y_pred = [], []

for images, labels in test_dataloader:        
    outputs = model(images)
                
    predicted = outputs.data.argmax(dim=1)
    y_true.extend(labels)
    y_pred.extend(predicted)

labels = train_data.classes  

confusion_mtx = confusion_matrix(y_true, y_pred)


disp = ConfusionMatrixDisplay(confusion_matrix=confusion_mtx, display_labels=labels)


f, ax = plt.subplots(figsize=(20, 20))
disp.plot(ax=ax, cmap="Greens")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix")
plt.show()